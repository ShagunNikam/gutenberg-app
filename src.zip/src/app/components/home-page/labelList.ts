const BOOK_LABEL__NAME = [
    {
        "name": 'fiction',
        "icon": "fa fa-flask"
    },
    {
        "name": 'drama',
        "icon": "fa fa-film"
    },
    {
        "name": 'humor',
        "icon": "fa fa-smile-o"
    },
    {
        "name": 'politics',
        "icon": "fa fa-male"
    },
    {
        "name": 'philosophy',
        "icon": "fa fa-dribbble"
    },
    {
        "name": 'history',
        "icon": "fa fa-history"
    },
    {
        "name": 'adventure',
        "icon": "fa fa-motorcycle"
    }
];

export {
    BOOK_LABEL__NAME
};